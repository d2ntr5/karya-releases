import {
  extractGmail,
  extractGmailSelected,
  countGmailSelected,
  extractCalendar,
  extractCalendarRange,
  accountFromGmailFeed,
} from "./extractors.js";

const HOST = "com.d2ntr5.karya";
const ACCOUNT_SLOTS = 6;

// ---- Google account: every feature needs the chosen account to be logged in.

// Accounts logged in to this Chrome profile, in Google's slot order
// (/u/0, /u/1, …). An empty slot answers 401 or redirects to the default
// account, which the email de-duplication drops.
async function googleAccounts() {
  const slots = await Promise.all(
    [...Array(ACCOUNT_SLOTS).keys()].map(async (index) => {
      try {
        const res = await fetch(`https://mail.google.com/mail/u/${index}/feed/atom`, { credentials: "include" });
        if (!res.ok) return null;
        const email = accountFromGmailFeed(await res.text());
        return email ? { index, email } : null;
      } catch {
        return null;
      }
    })
  );
  const seen = new Set();
  return slots.filter((a) => a && !seen.has(a.email) && seen.add(a.email));
}

async function accountState() {
  const { account = null } = await chrome.storage.local.get("account");
  const accounts = await googleAccounts();
  const current = account ? accounts.find((a) => a.email === account) : null;
  return { account, accounts, loggedIn: Boolean(current), index: current ? current.index : null };
}

async function requireAccount() {
  const state = await accountState();
  if (!state.account) throw new Error("Google 계정을 먼저 고르세요.");
  if (!state.loggedIn) throw new Error(`${state.account} 계정이 로그인돼 있지 않습니다.`);
  return state;
}

// One native message per batch: Chrome starts the bridge, which drops each
// item into the app's inbox folder and exits.
async function sendToApp(items) {
  const capturedAt = new Date().toISOString();
  const reply = await chrome.runtime.sendNativeMessage(HOST, {
    type: "items",
    items: items.map(({ partial, ...item }) => ({ ...item, capturedAt })),
  });
  if (!reply || !reply.ok) throw new Error(reply?.error || "Karya 앱 응답 없음");
  return items.length;
}

async function run(tabId, func, world = "ISOLATED") {
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func, world });
  return result;
}

async function captureTab(tab, account) {
  const url = new URL(tab.url);
  let items;
  if (url.host === "mail.google.com") {
    const slot = url.pathname.match(/^\/mail\/u\/(\d+)\//);
    if (slot && Number(slot[1]) !== account.index) {
      throw new Error(`${account.account} 계정의 Gmail 탭에서 실행해 주세요.`);
    }
    // An open thread wins; otherwise the ticked rows of the list.
    const open = await run(tab.id, extractGmail);
    items = open ? [open] : await run(tab.id, extractGmailSelected, "MAIN");
    if (!items?.length) throw new Error("메일을 열거나, 목록에서 보낼 메일을 체크해 주세요.");
  } else if (url.host === "calendar.google.com") {
    const result = await run(tab.id, extractCalendar);
    items = Array.isArray(result) ? result : result ? [result] : [];
    if (!items.length) throw new Error("읽을 일정이 없습니다. 일정이 보이는 화면에서 실행해 주세요.");
  } else {
    throw new Error("Gmail 또는 Google 캘린더 탭에서 실행해 주세요.");
  }
  return items;
}

// Reads the asked range in a Google Calendar tab that is already open for the
// chosen account (no new tab). If that tab shows another day or week, it goes
// to the asked range for the read and then back to where it was.
async function captureCalendarRange(range, account) {
  const d = new Date();
  if (range === "nextWeek") d.setDate(d.getDate() + 7);
  const view = range === "today" ? "day" : "week";
  const url = `https://calendar.google.com/calendar/u/${account.index}/r/${view}/${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;

  const tab = await calendarTab(account);
  if (!tab) throw new Error(`${account.account} 계정의 Google 캘린더 탭을 먼저 열어 주세요.`);
  const back = tab.url;
  const moved = back !== url;
  try {
    if (moved) await loadInTab(tab.id, url);
    const tabUrl = (await chrome.tabs.get(tab.id)).url || "";
    if (!tabUrl.startsWith("https://calendar.google.com/")) throw new Error("Google 캘린더에 로그인해 주세요.");
    const items = await run(tab.id, extractCalendarRange);
    if (!items?.length) throw new Error("이 기간에 일정이 없습니다.");
    return items;
  } finally {
    if (moved) chrome.tabs.update(tab.id, { url: back }).catch(() => {});
  }
}

// 월별 일정 가져오기: the month's weeks one by one in week view (month view hides chips
// behind 「+N개 더보기」), then the events dated in that month. The tab goes back to where it was.
async function captureCalendarMonth(year, month, account) {
  const tab = await calendarTab(account);
  if (!tab) throw new Error(`${account.account} 계정의 Google 캘린더 탭을 먼저 열어 주세요.`);
  const back = tab.url;
  const first = new Date(year, month - 1, 1);
  const next = new Date(year, month, 1);
  const week = new Date(first);
  week.setDate(first.getDate() - first.getDay()); // the Sunday on or before the 1st
  const seen = new Map();
  try {
    for (; week < next; week.setDate(week.getDate() + 7)) {
      const url = `https://calendar.google.com/calendar/u/${account.index}/r/week/${week.getFullYear()}/${week.getMonth() + 1}/${week.getDate()}`;
      await loadInTab(tab.id, url);
      const tabUrl = (await chrome.tabs.get(tab.id)).url || "";
      if (!tabUrl.startsWith("https://calendar.google.com/")) throw new Error("Google 캘린더에 로그인해 주세요.");
      for (const item of (await run(tab.id, extractCalendarRange)) || []) {
        const days = [...item.body.matchAll(/(\d{4})년 (\d{1,2})월 (\d{1,2})일/g)].map((d) => new Date(+d[1], +d[2] - 1, +d[3]));
        const inMonth = days.some((d) => d >= first && d < next) || (days.length && days[0] < first && days[days.length - 1] >= next);
        if (inMonth && !seen.has(item.url)) seen.set(item.url, item);
      }
    }
  } finally {
    chrome.tabs.update(tab.id, { url: back }).catch(() => {});
  }
  if (!seen.size) throw new Error(`${year}년 ${month}월에 일정이 없습니다.`);
  return [...seen.values()];
}

// An open calendar tab of the account's slot (/calendar/u/N/; no /u/ = slot 0),
// the one in the current window first.
async function calendarTab(account) {
  const tabs = await chrome.tabs.query({ url: "https://calendar.google.com/calendar/*" });
  const slot = (t) => {
    const m = new URL(t.url).pathname.match(/^\/calendar\/u\/(\d+)\//);
    return m ? Number(m[1]) : 0;
  };
  const mine = tabs.filter((t) => slot(t) === account.index);
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  return mine.find((t) => t.windowId === current?.windowId) || mine[0] || null;
}

function loadInTab(tabId, url) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => done(reject, new Error("캘린더를 여는 데 시간이 너무 걸립니다.")), 20000);
    const listener = (id, info) => id === tabId && info.status === "complete" && done(resolve);
    const done = (fn, arg) => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      fn(arg);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.update(tabId, { url }).catch((e) => done(reject, e));
  });
}

async function peekActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.startsWith("https://mail.google.com/")) return { selected: 0 };
  try {
    return { selected: await run(tab.id, countGmailSelected) };
  } catch {
    return { selected: 0 };
  }
}

const partialNote = (items) => {
  const n = items.filter((i) => i.partial).length;
  return n ? ` (${n}통은 본문을 못 읽어 미리보기만)` : "";
};

// Toolbar badge for actions without a popup (right-click send).
function flashBadge(text, color) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2500);
}

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  (async () => {
    if (msg.type === "accountState") return { ok: true, ...(await accountState()) };
    if (msg.type === "setAccount") {
      await chrome.storage.local.set({ account: msg.email || null });
      return { ok: true, ...(await accountState()) };
    }
    if (msg.type === "peek") return { ok: true, ...(await peekActiveTab()) };
    const account = await requireAccount();
    if (msg.type === "captureActiveTab") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const items = await captureTab(tab, account);
      return { ok: true, count: await sendToApp(items), note: partialNote(items) };
    }
    if (msg.type === "captureCalendar") {
      return { ok: true, count: await sendToApp(await captureCalendarRange(msg.range, account)) };
    }
    if (msg.type === "captureCalendarMonth") {
      return { ok: true, count: await sendToApp(await captureCalendarMonth(msg.year, msg.month, account)) };
    }
    if (msg.type === "sendMemo") {
      return { ok: true, count: await sendToApp([{ source: "memo", title: "", body: msg.text, url: null }]) };
    }
    throw new Error(`unknown message ${msg.type}`);
  })().then(respond, (e) => respond({ ok: false, error: e.message }));
  return true;
});

// Tells the app which extension version is loaded, so its update guide can
// check the last step. Runs on install, on reload/update and on Chrome start.
function helloApp() {
  chrome.runtime
    .sendNativeMessage(HOST, { type: "hello", version: chrome.runtime.getManifest().version })
    .catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() =>
    chrome.contextMenus.create({ id: "karya-selection", title: "선택한 텍스트를 Karya로 보내기", contexts: ["selection"] })
  );
  helloApp();
});
chrome.runtime.onStartup.addListener(helloApp);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "karya-selection") return;
  try {
    await requireAccount();
    await sendToApp([{ source: "memo", title: tab?.title || "", body: info.selectionText, url: info.pageUrl }]);
    flashBadge("✓", "#15803D");
  } catch (e) {
    console.error("Karya:", e);
    flashBadge("!", "#B91C1C");
  }
});
