// Page extractors injected with chrome.scripting.executeScript.
// Each function must be self-contained: it runs in the page, not here.
// Gmail and Calendar class names are not a public API — when Google changes
// the page, these selectors are the only place that needs fixing.

export function extractGmail() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const subject = text(document.querySelector("h2.hP"));
  if (!subject) return null;

  const messages = [...document.querySelectorAll("div.adn")].map((m) => {
    const from = m.querySelector("span.gD");
    const date = m.querySelector("span.g3");
    return {
      from: from ? `${from.getAttribute("name") || ""} <${from.getAttribute("email") || ""}>` : "",
      date: date ? date.getAttribute("title") || text(date) : "",
      body: text(m.querySelector("div.a3s")),
    };
  });

  const body = messages
    .map((m) => `From: ${m.from}\nDate: ${m.date}\n\n${m.body}`)
    .join("\n\n---\n\n")
    .slice(0, 20000);

  return { source: "mail", title: subject, body, url: location.href };
}

export function extractCalendar() {
  const text = (el) => (el ? el.innerText.trim() : "");

  // An open event detail dialog wins over the grid.
  const dialog = document.querySelector('[role="dialog"]');
  if (dialog && text(dialog)) {
    const lines = text(dialog).split("\n").filter(Boolean);
    return [{ source: "calendar", title: lines[0] || "", body: lines.slice(1).join("\n"), url: location.href }];
  }

  // Otherwise every event chip visible in the current view.
  const seen = new Set();
  return [...document.querySelectorAll("[data-eventid]")]
    .map((el) => {
      const id = el.getAttribute("data-eventid");
      const label = text(el);
      if (!label || seen.has(id)) return null;
      seen.add(id);
      const lines = label.split("\n").filter(Boolean);
      return { source: "calendar", title: lines.find((l) => !/\d{1,2}:\d{2}|오전|오후|am|pm/i.test(l)) || lines[0], body: label, url: location.href };
    })
    .filter(Boolean);
}

// Gmail list view: the rows the user ticked. Runs in the page's MAIN world
// (needs window.GLOBALS for the "ik" key) and fetches each thread's print
// view from the same origin, so the logged-in session is reused.
// Without a readable print view the row's subject and preview still go out.
export async function extractGmailSelected() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const rows = [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  );
  const ik = window.GLOBALS?.[9];
  const base = location.origin + location.pathname;

  const toText = (html) => {
    const doc = new DOMParser().parseFromString(
      html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|table|h\d)>/gi, "$&\n"),
      "text/html"
    );
    doc.querySelectorAll("script, style").forEach((el) => el.remove());
    return (doc.body?.textContent || "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  };

  return Promise.all(
    rows.slice(0, 50).map(async (r) => {
      const thread = r.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id");
      const sender = r.querySelector("span[email]");
      const subject = text(r.querySelector("span.bog"));
      const head = `From: ${sender ? `${sender.getAttribute("name") || ""} <${sender.getAttribute("email") || ""}>` : ""}`;
      let body = `${head}\n\n${text(r.querySelector("span.y2"))}`;
      let partial = true;
      if (ik && thread) {
        try {
          const res = await fetch(`${base}?ik=${ik}&view=pt&search=all&th=${thread}`, { credentials: "include" });
          if (res.ok) {
            body = toText(await res.text());
            partial = false;
          }
        } catch {}
      }
      return {
        source: "mail",
        title: subject,
        body: body.slice(0, 20000),
        url: thread ? `${base}#all/${thread}` : location.href,
        partial,
      };
    })
  );
}

// How many list rows are ticked; the popup uses it to relabel its button.
export function countGmailSelected() {
  return [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  ).length;
}

// Calendar day/week view in an open calendar tab: wait for the grid to
// render, then read every event chip. textContent (not innerText) keeps the
// screen-reader text, which carries the date and time of each chip.
export async function extractCalendarRange() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let i = 0; i < 40 && !document.querySelector('[role="main"]'); i++) await sleep(250);
  await sleep(1500);

  // Names in the side list ("내 캘린더", shared calendars): 이주호, 무신사, 이마트 …
  // A chip's screen-reader text names its calendar; match it against these.
  const calendars = new Set(
    [...document.querySelectorAll('input[type="checkbox"][aria-label]')]
      .map((el) => el.getAttribute("aria-label").trim())
      .filter(Boolean)
  );

  const seen = new Set();
  return [...document.querySelectorAll("[data-eventid]")]
    .map((el) => {
      const id = el.getAttribute("data-eventid");
      const label = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (!label || seen.has(id)) return null;
      seen.add(id);
      const parts = label.split(/,\s*/).filter(Boolean);
      const calendar = parts.find((p) => calendars.has(p)) || "";
      return {
        source: "calendar",
        title: parts.find((p) => p !== calendar && !/\d{1,2}:\d{2}|\d+시|오전|오후|am|pm|\d{4}년/i.test(p)) || parts[0],
        body: calendar ? `캘린더: ${calendar}\n${label}` : label,
        calendar,
        url: `https://calendar.google.com/calendar/event?eid=${encodeURIComponent(id)}`,
      };
    })
    .filter(Boolean);
}

// Gmail's Atom feed (/mail/u/N/feed/atom) names the account in its feed
// title, e.g. "Gmail - Inbox for name@company.com". Not a public contract
// either: if Google changes it, fix it here.
export function accountFromGmailFeed(xml) {
  const head = xml.split("<entry")[0];
  const m = head.match(/<title>[^<]*?([^\s<>()]+@[^\s<>()]+)[^<]*<\/title>/);
  return m ? m[1].toLowerCase() : null;
}
