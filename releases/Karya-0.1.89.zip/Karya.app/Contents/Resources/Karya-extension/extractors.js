// Page extractors injected with chrome.scripting.executeScript.
// Each function must be self-contained: it runs in the page, not here.
// Gmail and Calendar class names are not a public API — when Google changes
// the page, these selectors are the only place that needs fixing.

export function extractGmail() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const subject = text(document.querySelector("h2.hP"));
  if (!subject) return null;

  const messages = [...document.querySelectorAll("div.adn")].map((m) => {
    const from = m.querySelector("span.gD");
    const date = m.querySelector("span.g3");
    return {
      from: from ? `${from.getAttribute("name") || ""} <${from.getAttribute("email") || ""}>` : "",
      date: date ? date.getAttribute("title") || text(date) : "",
      body: text(m.querySelector("div.a3s")),
    };
  });

  const body = messages
    .map((m) => `From: ${m.from}\nDate: ${m.date}\n\n${m.body}`)
    .join("\n\n---\n\n")
    .slice(0, 20000);

  return { source: "mail", title: subject, body, url: location.href };
}

// Gmail list view: the rows the user ticked. Runs in the page's MAIN world
// (needs window.GLOBALS for the "ik" key) and fetches each thread's print
// view from the same origin, so the logged-in session is reused.
// Without a readable print view the row's subject and preview still go out.
export async function extractGmailSelected() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const rows = [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  );
  const ik = window.GLOBALS?.[9];
  const base = location.origin + location.pathname;

  // Gmail enforces Trusted Types: without a policy the parse threw and every ticked mail went out as its
  // preview only (「본문을 못 읽어 미리보기만」, 2026-11-03) — the same fix readGmailThreads got in 0.1.51.
  let policy = null;
  try {
    policy = window.trustedTypes?.createPolicy(`karya-selected-${Date.now()}`, { createHTML: (s) => s }) || null;
  } catch {}
  const toText = (html) => {
    const marked = html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|table|h\d)>/gi, "$&\n");
    const doc = new DOMParser().parseFromString(policy ? policy.createHTML(marked) : marked, "text/html");
    doc.querySelectorAll("script, style").forEach((el) => el.remove());
    return (doc.body?.textContent || "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  };

  return Promise.all(
    rows.slice(0, 50).map(async (r) => {
      const thread = r.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id");
      const sender = r.querySelector("span[email]");
      const subject = text(r.querySelector("span.bog"));
      const head = `From: ${sender ? `${sender.getAttribute("name") || ""} <${sender.getAttribute("email") || ""}>` : ""}`;
      let body = `${head}\n\n${text(r.querySelector("span.y2"))}`;
      let partial = true;
      if (ik && thread) {
        try {
          const res = await fetch(`${base}?ik=${ik}&view=pt&search=all&th=${thread}`, { credentials: "include" });
          if (res.ok) {
            body = toText(await res.text());
            partial = false;
          }
        } catch {}
      }
      return {
        source: "mail",
        title: subject,
        body: body.slice(0, 20000),
        url: thread ? `${base}#all/${thread}` : location.href,
        partial,
      };
    })
  );
}

// Gmail search, page by page, in the open Gmail tab (MAIN world): sets the search in the address
// (#search/<query>, then /p2, /p3 …) and reads the result rows (docs/MAIL-DESIGN.md 1). Returns
// [{ thread, subject, date }] — `date` is the row's full date tooltip. The rows' look is not a public
// API (확인 안 됨 against every Gmail layout): a page that never shows rows ends the search.
// textContent, not innerText: from the popup the Gmail tab is often in the background, and on
// 2026-10-31 both subjects came back empty that way (readGmailThreads also takes the print view's).
// One step per call: the service worker sets the address (`gmailSearch`) and polls the rows
// (`gmailRows`) — `searchGmail` in background.js. The waiting used to be a 300 ms timer chain in the page; in a
// Gmail tab hidden over 5 minutes Chrome runs such chains once a minute (intensive throttling, Chrome 88), so a
// search with no result took up to 40 minutes and 「일정 관련 메일 찾기」 never ended (2026-11-03).
export function gmailSearch(hash) {
  location.hash = hash;
}

export function gmailRows() {
  const text = (el) => (el ? el.textContent.trim() : "");
  return [...document.querySelectorAll("tr.zA")]
    .filter((r) => r.offsetParent)
    .map((r) => {
      const dateEl = r.querySelector("td.xW span[title]") || r.querySelector("span[title][aria-label]");
      return {
        thread: r.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id") || null,
        subject: text(r.querySelector("span.bog")),
        date: dateEl?.getAttribute("title") || "",
      };
    });
}

// Each thread's print view (?view=pt) split into messages (MAIN world, needs GLOBALS[9] = ik).
// Print view (checked on mail.google.com 2026-10-31): the thread's subject in the first
// <font size="+1"><b>, one <table class="message"> per message, its first row "Name <address>" | date
// ("2026년 10월 30일 오전 11:35"), then 답장 주소/받는사람/참조 rows, then the body. Gmail enforces Trusted Types,
// so the HTML goes through a policy before DOMParser (without it the parse threw and every thread came
// back empty). `mine` is the message without quoted earlier mail.
export async function readGmailThreads(threads) {
  const ik = window.GLOBALS?.[9];
  const base = location.origin + location.pathname;
  let policy = null;
  try {
    policy = window.trustedTypes?.createPolicy(`karya-print-${Date.now()}`, { createHTML: (s) => s }) || null;
  } catch {}
  const clean = (s) => s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const toDoc = (html) => {
    const marked = html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|table|h\d)>/gi, "$&\n");
    return new DOMParser().parseFromString(policy ? policy.createHTML(marked) : marked, "text/html");
  };
  const header = /^\s*(답장 주소|받는사람|참조|숨은참조|Reply-To|To|Cc|Bcc)\s*:/i;
  const read = async (thread) => {
    if (!ik) return { thread, subject: "", text: "", messages: [] };
    try {
      const res = await fetch(`${base}?ik=${ik}&view=pt&search=all&th=${thread}`, { credentials: "include" });
      if (!res.ok) return { thread, subject: "", text: "", messages: [] };
      const doc = toDoc(await res.text());
      doc.querySelectorAll("script, style").forEach((el) => el.remove());
      const subject = (doc.querySelector('font[size="+1"] b')?.textContent || "").trim();
      const messages = [...doc.querySelectorAll("table.message")].map((t) => {
        const head = t.querySelector("tr");
        const sender = head ? head.querySelector("td")?.textContent || head.textContent : "";
        const from = (sender.match(/<([^<>\s]+@[^<>\s]+)>/) || sender.match(/([^<>\s]+@[^<>\s]+)/) || [])[1] || "";
        const name = sender.replace(/<[^>]*>/g, "").trim();
        const dateCell = head ? [...head.querySelectorAll("td")].pop() : null;
        const at = dateCell ? dateCell.textContent.trim() : "";
        const body = t.cloneNode(true);
        body.querySelector("tr")?.remove();
        [...body.querySelectorAll("tr")].filter((r) => header.test(r.textContent)).forEach((r) => r.remove());
        const full = clean(body.textContent || "");
        body.querySelectorAll(".gmail_quote, blockquote").forEach((q) => q.remove());
        return { from, name, at, text: full.slice(0, 8000), mine: clean(body.textContent || "").slice(0, 8000) };
      });
      return { thread, subject, text: clean(doc.body?.textContent || "").slice(0, 20000), messages };
    } catch {
      return { thread, subject: "", text: "", messages: [] };
    }
  };
  const out = [];
  for (let i = 0; i < threads.length; i += 4) out.push(...(await Promise.all(threads.slice(i, i + 4).map(read))));
  return out;
}

// How many list rows are ticked; the popup uses it to relabel its button.
export function countGmailSelected() {
  return [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  ).length;
}

// Gmail's Atom feed (/mail/u/N/feed/atom) names the account in its feed
// title, e.g. "Gmail - Inbox for name@company.com". Not a public contract
// either: if Google changes it, fix it here.
export function accountFromGmailFeed(xml) {
  const head = xml.split("<entry")[0];
  const m = head.match(/<title>[^<]*?([^\s<>()]+@[^\s<>()]+)[^<]*<\/title>/);
  return m ? m[1].toLowerCase() : null;
}
