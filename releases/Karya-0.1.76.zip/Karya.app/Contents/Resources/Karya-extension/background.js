import {
  extractGmail,
  extractGmailSelected,
  countGmailSelected,
  extractCalendar,
  extractCalendarRange,
  accountFromGmailFeed,
  gmailSearch,
  gmailRows,
  readGmailThreads,
} from "./extractors.js";

const HOST = "com.d2ntr5.karya";
const ACCOUNT_SLOTS = 6;

// ---- Google account: every feature needs the chosen account to be logged in.

// Accounts logged in to this Chrome profile, in Google's slot order
// (/u/0, /u/1, …). An empty slot answers 401 or redirects to the default
// account, which the email de-duplication drops.
async function googleAccounts() {
  const slots = await Promise.all(
    [...Array(ACCOUNT_SLOTS).keys()].map(async (index) => {
      try {
        const res = await fetch(`https://mail.google.com/mail/u/${index}/feed/atom`, { credentials: "include" });
        if (!res.ok) return null;
        const email = accountFromGmailFeed(await res.text());
        return email ? { index, email } : null;
      } catch {
        return null;
      }
    })
  );
  const seen = new Set();
  return slots.filter((a) => a && !seen.has(a.email) && seen.add(a.email));
}

async function accountState() {
  const { account = null } = await chrome.storage.local.get("account");
  const accounts = await googleAccounts();
  const current = account ? accounts.find((a) => a.email === account) : null;
  return { account, accounts, loggedIn: Boolean(current), index: current ? current.index : null };
}

async function requireAccount() {
  const state = await accountState();
  if (!state.account) throw new Error("Google 계정을 먼저 고르세요.");
  if (!state.loggedIn) throw new Error(`${state.account} 계정이 로그인돼 있지 않습니다.`);
  return state;
}

// One native message per batch: Chrome starts the bridge, which drops each
// item into the app's inbox folder and exits.
async function sendToApp(items) {
  const capturedAt = new Date().toISOString();
  const reply = await chrome.runtime.sendNativeMessage(HOST, {
    type: "items",
    items: items.map(({ partial, ...item }) => ({ ...item, capturedAt })),
  });
  if (!reply || !reply.ok) throw new Error(reply?.error || "Karya 앱 응답 없음");
  return items.length;
}

async function run(tabId, func, world = "ISOLATED", args = []) {
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func, world, args });
  return result;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Gmail search, page by page (#search/<query>, then /p2, /p3 …), in the open Gmail tab. The waiting is here,
// not in the page (see `gmailSearch`): each page waits up to 12 s for rows that differ from the page before.
async function searchGmail(tabId, query, maxPages) {
  const q = encodeURIComponent(query).replace(/%20/g, "+");
  const found = new Map();
  let previous = null;
  for (let page = 1; page <= maxPages; page++) {
    await run(tabId, gmailSearch, "MAIN", [`#search/${q}` + (page > 1 ? `/p${page}` : "")]);
    let rows = [];
    for (let i = 0; i < 40; i++) {
      await sleep(300);
      rows = (await run(tabId, gmailRows, "MAIN")) || [];
      if (rows.length && rows[0].thread && rows[0].thread !== previous) break;
      rows = [];
    }
    if (!rows.length) break;
    previous = rows[0].thread;
    let added = 0;
    for (const r of rows) {
      if (!r.thread || found.has(r.thread)) continue;
      found.set(r.thread, r);
      added++;
    }
    if (!added || rows.length < 20) break;
  }
  return [...found.values()];
}

async function captureTab(tab, account) {
  const url = new URL(tab.url);
  let items;
  if (url.host === "mail.google.com") {
    const slot = url.pathname.match(/^\/mail\/u\/(\d+)\//);
    if (slot && Number(slot[1]) !== account.index) {
      throw new Error(`${account.account} 계정의 Gmail 탭에서 실행해 주세요.`);
    }
    // An open thread wins; otherwise the ticked rows of the list.
    const open = await run(tab.id, extractGmail);
    items = open ? [open] : await run(tab.id, extractGmailSelected, "MAIN");
    if (!items?.length) throw new Error("메일을 열거나, 목록에서 보낼 메일을 체크해 주세요.");
  } else if (url.host === "calendar.google.com") {
    const result = await run(tab.id, extractCalendar);
    items = Array.isArray(result) ? result : result ? [result] : [];
    if (!items.length) throw new Error("읽을 일정이 없습니다. 일정이 보이는 화면에서 실행해 주세요.");
  } else {
    throw new Error("Gmail 또는 Google 캘린더 탭에서 실행해 주세요.");
  }
  return items;
}

// Reads the asked range in a Google Calendar tab that is already open for the
// chosen account (no new tab). If that tab shows another day or week, it goes
// to the asked range for the read and then back to where it was.
async function captureCalendarRange(range, account) {
  const d = new Date();
  if (range === "nextWeek") d.setDate(d.getDate() + 7);
  const view = range === "today" ? "day" : "week";
  const url = `https://calendar.google.com/calendar/u/${account.index}/r/${view}/${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;

  const tab = await calendarTab(account);
  if (!tab) throw new Error(`${account.account} 계정의 Google 캘린더 탭을 먼저 열어 주세요.`);
  const back = tab.url;
  const moved = back !== url;
  try {
    if (moved) await loadInTab(tab.id, url);
    const tabUrl = (await chrome.tabs.get(tab.id)).url || "";
    if (!tabUrl.startsWith("https://calendar.google.com/")) throw new Error("Google 캘린더에 로그인해 주세요.");
    const items = await run(tab.id, extractCalendarRange);
    if (!items?.length) throw new Error("이 기간에 일정이 없습니다.");
    return items;
  } finally {
    if (moved) chrome.tabs.update(tab.id, { url: back }).catch(() => {});
  }
}

// 월별 일정 가져오기: the month's weeks one by one in week view (month view hides chips
// behind 「+N개 더보기」), then the events dated in that month. The tab goes back to where it was.
async function captureCalendarMonth(year, month, account) {
  const tab = await calendarTab(account);
  if (!tab) throw new Error(`${account.account} 계정의 Google 캘린더 탭을 먼저 열어 주세요.`);
  const back = tab.url;
  const first = new Date(year, month - 1, 1);
  const next = new Date(year, month, 1);
  const week = new Date(first);
  week.setDate(first.getDate() - first.getDay()); // the Sunday on or before the 1st
  const seen = new Map();
  try {
    for (; week < next; week.setDate(week.getDate() + 7)) {
      const url = `https://calendar.google.com/calendar/u/${account.index}/r/week/${week.getFullYear()}/${week.getMonth() + 1}/${week.getDate()}`;
      await loadInTab(tab.id, url);
      const tabUrl = (await chrome.tabs.get(tab.id)).url || "";
      if (!tabUrl.startsWith("https://calendar.google.com/")) throw new Error("Google 캘린더에 로그인해 주세요.");
      for (const item of (await run(tab.id, extractCalendarRange)) || []) {
        const days = [...item.body.matchAll(/(\d{4})년 (\d{1,2})월 (\d{1,2})일/g)].map((d) => new Date(+d[1], +d[2] - 1, +d[3]));
        const inMonth = days.some((d) => d >= first && d < next) || (days.length && days[0] < first && days[days.length - 1] >= next);
        if (inMonth && !seen.has(item.url)) seen.set(item.url, item);
      }
    }
  } finally {
    chrome.tabs.update(tab.id, { url: back }).catch(() => {});
  }
  if (!seen.size) throw new Error(`${year}년 ${month}월에 일정이 없습니다.`);
  return [...seen.values()];
}

// ---- Mail (docs/MAIL-DESIGN.md)

// An open Gmail tab of the account's slot (/mail/u/N/), the one in the current window first.
async function gmailTab(account) {
  const tabs = await chrome.tabs.query({ url: "https://mail.google.com/mail/*" });
  const slot = (t) => {
    const m = new URL(t.url).pathname.match(/^\/mail\/u\/(\d+)\//);
    return m ? Number(m[1]) : 0;
  };
  const mine = tabs.filter((t) => slot(t) === account.index);
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  return mine.find((t) => t.windowId === current?.windowId) || mine[0] || null;
}

// [from, to) for 이번 주 (Monday on), 지난주, 이번 달.
function period(range) {
  const now = new Date();
  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (range === "thisMonth") return [new Date(now.getFullYear(), now.getMonth(), 1), new Date(now.getFullYear(), now.getMonth() + 1, 1)];
  const monday = new Date(day);
  monday.setDate(day.getDate() - ((day.getDay() + 6) % 7));
  if (range === "lastWeek") monday.setDate(monday.getDate() - 7);
  const next = new Date(monday);
  next.setDate(monday.getDate() + 7);
  return [monday, next];
}
const gmailDay = (d) => `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;

// Runs `work` in the account's Gmail tab and puts the tab back where it was.
async function inGmail(account, work) {
  const tab = await gmailTab(account);
  if (!tab) throw new Error(`${account.account} 계정의 Gmail 탭을 먼저 열어 주세요.`);
  const back = tab.url;
  try {
    return await work(tab);
  } finally {
    chrome.tabs.update(tab.id, { url: back }).catch(() => {});
  }
}

// 보낸 메일 가져오기: threads with my mail in the period, split into messages; the app makes the cards
// (one per sent mail, close ones in a thread merged, 1 h of writing — 30 min when short).
async function captureSentMail(range, account) {
  const [from, to] = period(range);
  const query = `from:me after:${gmailDay(from)} before:${gmailDay(to)}`;
  return inGmail(account, async (tab) => {
    const rows = (await searchGmail(tab.id, query, 20)) || [];
    if (!rows.length) throw new Error("이 기간에 보낸 메일이 없습니다(또는 검색 결과를 읽지 못했습니다).");
    const threads = (await run(tab.id, readGmailThreads, "MAIN", [rows.map((r) => r.thread)])) || [];
    const byThread = new Map(threads.map((t) => [t.thread, t]));
    return rows.map((r) => {
      const t = byThread.get(r.thread) || { subject: "", text: "", messages: [] };
      return {
        source: "mail", kind: "sent", title: r.subject || t.subject, thread: r.thread, rowDate: r.date,
        me: account.account, from: from.toISOString(), to: to.toISOString(),
        messages: t.messages, body: t.text,
        url: `https://mail.google.com/mail/u/${account.index}/#all/${r.thread}`,
      };
    });
  });
}

// 일정 관련 메일 찾기: the period's calendar events, then for each a Gmail search by its title words
// in the two weeks before (invitations and threads about it, answered or not — 결정 5).
// Chrome ends the service worker when one message takes over 5 minutes (developer.chrome.com, service worker
// lifecycle): a week of 17 events, each searched (a search with no result waits 12 s), once ran past it on
// 2026-11-03 — the popup stayed on 「보내는 중…」 and the Gmail tab stayed on the search. The search stops at
// 4 minutes and sends what it found, saying how many events were left; the same title is searched once.
const RELATED_BUDGET_MS = 4 * 60 * 1000;

async function captureRelatedMail(range, account) {
  const started = Date.now();
  const events = await captureCalendarRange(range, account);
  return inGmail(account, async (tab) => {
    const out = [];
    const searched = new Set();
    let left = 0;
    for (const [i, ev] of events.slice(0, 40).entries()) {
      if (Date.now() - started > RELATED_BUDGET_MS) {
        left = Math.min(events.length, 40) - i;
        break;
      }
      const words = (ev.title || "").replace(/\[[^\]]*\]/g, " ").replace(/["()]/g, " ").trim();
      const m = (ev.body || "").match(/(\d{4})년 (\d{1,2})월 (\d{1,2})일/);
      if (!words || !m || searched.has(words)) continue;
      searched.add(words);
      const day = new Date(+m[1], +m[2] - 1, +m[3]);
      const after = new Date(day);
      after.setDate(day.getDate() - 14);
      const before = new Date(day);
      before.setDate(day.getDate() + 2);
      const rows = ((await searchGmail(tab.id, `subject:(${words}) after:${gmailDay(after)} before:${gmailDay(before)}`, 1)) || []).slice(0, 3);
      if (!rows.length) continue;
      const threads = (await run(tab.id, readGmailThreads, "MAIN", [rows.map((r) => r.thread)])) || [];
      out.push({
        source: "related", eventUrl: ev.url, title: ev.title, body: "",
        candidates: rows.map((r) => ({
          thread: r.thread, subject: r.subject || threads.find((t) => t.thread === r.thread)?.subject || "", date: r.date,
          text: (threads.find((t) => t.thread === r.thread)?.text || "").slice(0, 6000),
          url: `https://mail.google.com/mail/u/${account.index}/#all/${r.thread}`,
        })),
      });
    }
    if (!out.length) {
      throw new Error(left ? `시간이 오래 걸려 일정 ${left}개는 찾지 못했고, 찾은 관련 메일이 없습니다.` : "이 기간 일정과 관련된 메일을 찾지 못했습니다.");
    }
    out.note = left ? ` 시간이 오래 걸려 일정 ${left}개는 찾지 않았습니다.` : "";
    return out;
  });
}

// An open calendar tab of the account's slot (/calendar/u/N/; no /u/ = slot 0),
// the one in the current window first.
async function calendarTab(account) {
  const tabs = await chrome.tabs.query({ url: "https://calendar.google.com/calendar/*" });
  const slot = (t) => {
    const m = new URL(t.url).pathname.match(/^\/calendar\/u\/(\d+)\//);
    return m ? Number(m[1]) : 0;
  };
  const mine = tabs.filter((t) => slot(t) === account.index);
  const [current] = await chrome.tabs.query({ active: true, currentWindow: true });
  return mine.find((t) => t.windowId === current?.windowId) || mine[0] || null;
}

function loadInTab(tabId, url) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => done(reject, new Error("캘린더를 여는 데 시간이 너무 걸립니다.")), 20000);
    const listener = (id, info) => id === tabId && info.status === "complete" && done(resolve);
    const done = (fn, arg) => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      fn(arg);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.update(tabId, { url }).catch((e) => done(reject, e));
  });
}

async function peekActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url?.startsWith("https://mail.google.com/")) return { selected: 0 };
  try {
    return { selected: await run(tab.id, countGmailSelected) };
  } catch {
    return { selected: 0 };
  }
}

const partialNote = (items) => {
  const n = items.filter((i) => i.partial).length;
  return n ? ` (${n}통은 본문을 못 읽어 미리보기만)` : "";
};

// Toolbar badge for actions without a popup (right-click send).
function flashBadge(text, color) {
  chrome.action.setBadgeBackgroundColor({ color });
  chrome.action.setBadgeText({ text });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2500);
}

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  (async () => {
    if (msg.type === "accountState") return { ok: true, ...(await accountState()) };
    if (msg.type === "setAccount") {
      await chrome.storage.local.set({ account: msg.email || null });
      return { ok: true, ...(await accountState()) };
    }
    if (msg.type === "peek") return { ok: true, ...(await peekActiveTab()) };
    const account = await requireAccount();
    if (msg.type === "captureActiveTab") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const items = await captureTab(tab, account);
      return { ok: true, count: await sendToApp(items), note: partialNote(items) };
    }
    if (msg.type === "captureCalendar") {
      return { ok: true, count: await sendToApp(await captureCalendarRange(msg.range, account)) };
    }
    if (msg.type === "captureCalendarMonth") {
      return { ok: true, count: await sendToApp(await captureCalendarMonth(msg.year, msg.month, account)) };
    }
    if (msg.type === "captureSentMail") {
      return { ok: true, count: await sendToApp(await captureSentMail(msg.range, account)) };
    }
    if (msg.type === "captureRelatedMail") {
      const items = await captureRelatedMail(msg.range, account);
      return { ok: true, count: await sendToApp(items), note: items.note };
    }
    if (msg.type === "sendMemo") {
      return { ok: true, count: await sendToApp([{ source: "memo", title: "", body: msg.text, url: null }]) };
    }
    throw new Error(`unknown message ${msg.type}`);
  })().then(respond, (e) => respond({ ok: false, error: e.message }));
  return true;
});

// Tells the app which extension version is loaded, so its update guide can
// check the last step. Runs on install, on reload/update, on Chrome start and
// every few minutes. The bridge answers with the version the app copied to the
// load folder (/Applications/Karya-extension, refreshed when the app updates):
// if that is newer, reload from disk so no one has to press ↻ in Chrome.
function helloApp() {
  chrome.runtime
    .sendNativeMessage(HOST, { type: "hello", version: chrome.runtime.getManifest().version })
    .then(reloadIfNewer)
    .catch(() => {});
}

function isNewer(a, b) {
  const x = a.split(".").map(Number), y = b.split(".").map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  }
  return false;
}

// Once per folder version: if Chrome loads this extension from another folder,
// a reload would not change the version, and must not repeat.
async function reloadIfNewer(reply) {
  const folder = reply?.folderVersion;
  if (!folder || !isNewer(folder, chrome.runtime.getManifest().version)) return;
  const { reloadedFor } = await chrome.storage.local.get("reloadedFor");
  if (reloadedFor === folder) return;
  await chrome.storage.local.set({ reloadedFor: folder });
  chrome.runtime.reload();
}

const HELLO_ALARM = "karya-hello";

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() =>
    chrome.contextMenus.create({ id: "karya-selection", title: "선택한 텍스트를 Karya로 보내기", contexts: ["selection"] })
  );
  startHello();
});
chrome.runtime.onStartup.addListener(startHello);

// Alarms may be cleared on browser restart, so set it again each start.
function startHello() {
  chrome.alarms.create(HELLO_ALARM, { periodInMinutes: 10 });
  helloApp();
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === HELLO_ALARM) helloApp();
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "karya-selection") return;
  try {
    await requireAccount();
    await sendToApp([{ source: "memo", title: tab?.title || "", body: info.selectionText, url: info.pageUrl }]);
    flashBadge("✓", "#15803D");
  } catch (e) {
    console.error("Karya:", e);
    flashBadge("!", "#B91C1C");
  }
});
