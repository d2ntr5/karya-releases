// Page extractors injected with chrome.scripting.executeScript.
// Each function must be self-contained: it runs in the page, not here.
// Gmail and Calendar class names are not a public API — when Google changes
// the page, these selectors are the only place that needs fixing.

export function extractGmail() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const subject = text(document.querySelector("h2.hP"));
  if (!subject) return null;

  const messages = [...document.querySelectorAll("div.adn")].map((m) => {
    const from = m.querySelector("span.gD");
    const date = m.querySelector("span.g3");
    return {
      from: from ? `${from.getAttribute("name") || ""} <${from.getAttribute("email") || ""}>` : "",
      date: date ? date.getAttribute("title") || text(date) : "",
      body: text(m.querySelector("div.a3s")),
    };
  });

  const body = messages
    .map((m) => `From: ${m.from}\nDate: ${m.date}\n\n${m.body}`)
    .join("\n\n---\n\n")
    .slice(0, 20000);

  return { source: "mail", title: subject, body, url: location.href };
}

export function extractCalendar() {
  const text = (el) => (el ? el.innerText.trim() : "");

  // An open event detail dialog wins over the grid.
  const dialog = document.querySelector('[role="dialog"]');
  if (dialog && text(dialog)) {
    const lines = text(dialog).split("\n").filter(Boolean);
    return [{ source: "calendar", title: lines[0] || "", body: lines.slice(1).join("\n"), url: location.href }];
  }

  // Otherwise every event chip of the days the view shows.
  // Only the days the tab shows. Google keeps the chips of weeks viewed before in the page:
  // on 2026-10-30 a tab on /r/week/2026/10/4 also held this week's (10/26–30) chips.
  // The shown days come from the address (/r/week/2026/10/18: the week from that Sunday or Monday;
  // /r/day/…: that day; /r/month/…: that month); a chip is kept when a date in its text falls there.
  const at = location.pathname.match(/\/r\/(?:([a-z]+)\/)?(\d{4})\/(\d{1,2})\/(\d{1,2})/);
  const view = at?.[1] || (location.pathname.match(/\/r\/([a-z]+)/) || [])[1] || "week";
  const pick = at ? new Date(+at[2], +at[3] - 1, +at[4]) : new Date();
  pick.setHours(0, 0, 0, 0);
  let from = new Date(pick);
  let to;
  if (view === "day") {
    to = new Date(pick); to.setDate(pick.getDate() + 1);
  } else if (view === "month") {
    from = new Date(pick.getFullYear(), pick.getMonth(), 1);
    to = new Date(pick.getFullYear(), pick.getMonth() + 1, 1);
  } else {
    if (pick.getDay() > 1) from.setDate(pick.getDate() - pick.getDay());
    to = new Date(from); to.setDate(from.getDate() + 7);
  }
  const inShown = (label) => {
    const days = [...label.matchAll(/(\d{4})년 (\d{1,2})월 (\d{1,2})일/g)].map((m) => new Date(+m[1], +m[2] - 1, +m[3]));
    if (!days.length) return true; // no date in the text: kept as before
    return days.some((d) => d >= from && d < to) || (days[0] < from && days[days.length - 1] >= to);
  };
  const seen = new Set();
  return [...document.querySelectorAll("[data-eventid]")]
    .map((el) => {
      const id = el.getAttribute("data-eventid");
      const label = text(el);
      if (!label || id.startsWith("_WL_") || seen.has(id) || !inShown(label)) return null;
      seen.add(id);
      const lines = label.split("\n").filter(Boolean);
      // A time line starts with the time ("오후 3시~ 6시"); a title may hold "pm" or "3시간" ("이마트 CSPM 교육").
      return { source: "calendar", title: lines.find((l) => !/^(오전|오후)\s*\d|^\d{1,2}(:\d{2})?\s*(am|pm)?\s*[~–-]|^\d{1,2}:\d{2}/i.test(l)) || lines[0], body: label,
        // The event's own address, as `extractCalendarRange` sends: the app drops a card with the same title and
        // address, and the page's address made 「현재 탭」 add a week already read with 「이번 주」 again (2026-11-03).
        url: `https://calendar.google.com/calendar/event?eid=${encodeURIComponent(id)}` };
    })
    .filter(Boolean);
}

// Gmail list view: the rows the user ticked. Runs in the page's MAIN world
// (needs window.GLOBALS for the "ik" key) and fetches each thread's print
// view from the same origin, so the logged-in session is reused.
// Without a readable print view the row's subject and preview still go out.
export async function extractGmailSelected() {
  const text = (el) => (el ? el.innerText.trim() : "");
  const rows = [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  );
  const ik = window.GLOBALS?.[9];
  const base = location.origin + location.pathname;

  // Gmail enforces Trusted Types: without a policy the parse threw and every ticked mail went out as its
  // preview only (「본문을 못 읽어 미리보기만」, 2026-11-03) — the same fix readGmailThreads got in 0.1.51.
  let policy = null;
  try {
    policy = window.trustedTypes?.createPolicy(`karya-selected-${Date.now()}`, { createHTML: (s) => s }) || null;
  } catch {}
  const toText = (html) => {
    const marked = html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|table|h\d)>/gi, "$&\n");
    const doc = new DOMParser().parseFromString(policy ? policy.createHTML(marked) : marked, "text/html");
    doc.querySelectorAll("script, style").forEach((el) => el.remove());
    return (doc.body?.textContent || "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  };

  return Promise.all(
    rows.slice(0, 50).map(async (r) => {
      const thread = r.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id");
      const sender = r.querySelector("span[email]");
      const subject = text(r.querySelector("span.bog"));
      const head = `From: ${sender ? `${sender.getAttribute("name") || ""} <${sender.getAttribute("email") || ""}>` : ""}`;
      let body = `${head}\n\n${text(r.querySelector("span.y2"))}`;
      let partial = true;
      if (ik && thread) {
        try {
          const res = await fetch(`${base}?ik=${ik}&view=pt&search=all&th=${thread}`, { credentials: "include" });
          if (res.ok) {
            body = toText(await res.text());
            partial = false;
          }
        } catch {}
      }
      return {
        source: "mail",
        title: subject,
        body: body.slice(0, 20000),
        url: thread ? `${base}#all/${thread}` : location.href,
        partial,
      };
    })
  );
}

// Gmail search, page by page, in the open Gmail tab (MAIN world): sets the search in the address
// (#search/<query>, then /p2, /p3 …) and reads the result rows (docs/MAIL-DESIGN.md 1). Returns
// [{ thread, subject, date }] — `date` is the row's full date tooltip. The rows' look is not a public
// API (확인 안 됨 against every Gmail layout): a page that never shows rows ends the search.
// textContent, not innerText: from the popup the Gmail tab is often in the background, and on
// 2026-10-31 both subjects came back empty that way (readGmailThreads also takes the print view's).
// One step per call: the service worker sets the address (`gmailSearch`) and polls the rows
// (`gmailRows`) — `searchGmail` in background.js. The waiting used to be a 300 ms timer chain in the page; in a
// Gmail tab hidden over 5 minutes Chrome runs such chains once a minute (intensive throttling, Chrome 88), so a
// search with no result took up to 40 minutes and 「일정 관련 메일 찾기」 never ended (2026-11-03).
export function gmailSearch(hash) {
  location.hash = hash;
}

export function gmailRows() {
  const text = (el) => (el ? el.textContent.trim() : "");
  return [...document.querySelectorAll("tr.zA")]
    .filter((r) => r.offsetParent)
    .map((r) => {
      const dateEl = r.querySelector("td.xW span[title]") || r.querySelector("span[title][aria-label]");
      return {
        thread: r.querySelector("[data-legacy-thread-id]")?.getAttribute("data-legacy-thread-id") || null,
        subject: text(r.querySelector("span.bog")),
        date: dateEl?.getAttribute("title") || "",
      };
    });
}

// Each thread's print view (?view=pt) split into messages (MAIN world, needs GLOBALS[9] = ik).
// Print view (checked on mail.google.com 2026-10-31): the thread's subject in the first
// <font size="+1"><b>, one <table class="message"> per message, its first row "Name <address>" | date
// ("2026년 10월 30일 오전 11:35"), then 답장 주소/받는사람/참조 rows, then the body. Gmail enforces Trusted Types,
// so the HTML goes through a policy before DOMParser (without it the parse threw and every thread came
// back empty). `mine` is the message without quoted earlier mail.
export async function readGmailThreads(threads) {
  const ik = window.GLOBALS?.[9];
  const base = location.origin + location.pathname;
  let policy = null;
  try {
    policy = window.trustedTypes?.createPolicy(`karya-print-${Date.now()}`, { createHTML: (s) => s }) || null;
  } catch {}
  const clean = (s) => s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const toDoc = (html) => {
    const marked = html.replace(/<br\s*\/?>/gi, "\n").replace(/<\/(p|div|tr|table|h\d)>/gi, "$&\n");
    return new DOMParser().parseFromString(policy ? policy.createHTML(marked) : marked, "text/html");
  };
  const header = /^\s*(답장 주소|받는사람|참조|숨은참조|Reply-To|To|Cc|Bcc)\s*:/i;
  const read = async (thread) => {
    if (!ik) return { thread, subject: "", text: "", messages: [] };
    try {
      const res = await fetch(`${base}?ik=${ik}&view=pt&search=all&th=${thread}`, { credentials: "include" });
      if (!res.ok) return { thread, subject: "", text: "", messages: [] };
      const doc = toDoc(await res.text());
      doc.querySelectorAll("script, style").forEach((el) => el.remove());
      const subject = (doc.querySelector('font[size="+1"] b')?.textContent || "").trim();
      const messages = [...doc.querySelectorAll("table.message")].map((t) => {
        const head = t.querySelector("tr");
        const sender = head ? head.querySelector("td")?.textContent || head.textContent : "";
        const from = (sender.match(/<([^<>\s]+@[^<>\s]+)>/) || sender.match(/([^<>\s]+@[^<>\s]+)/) || [])[1] || "";
        const name = sender.replace(/<[^>]*>/g, "").trim();
        const dateCell = head ? [...head.querySelectorAll("td")].pop() : null;
        const at = dateCell ? dateCell.textContent.trim() : "";
        const body = t.cloneNode(true);
        body.querySelector("tr")?.remove();
        [...body.querySelectorAll("tr")].filter((r) => header.test(r.textContent)).forEach((r) => r.remove());
        const full = clean(body.textContent || "");
        body.querySelectorAll(".gmail_quote, blockquote").forEach((q) => q.remove());
        return { from, name, at, text: full.slice(0, 8000), mine: clean(body.textContent || "").slice(0, 8000) };
      });
      return { thread, subject, text: clean(doc.body?.textContent || "").slice(0, 20000), messages };
    } catch {
      return { thread, subject: "", text: "", messages: [] };
    }
  };
  const out = [];
  for (let i = 0; i < threads.length; i += 4) out.push(...(await Promise.all(threads.slice(i, i + 4).map(read))));
  return out;
}

// How many list rows are ticked; the popup uses it to relabel its button.
export function countGmailSelected() {
  return [...document.querySelectorAll("tr.zA")].filter(
    (r) => r.offsetParent && r.querySelector('[role="checkbox"][aria-checked="true"]')
  ).length;
}

// Calendar day/week view in an open calendar tab: wait for the grid to
// render, then read every event chip. textContent (not innerText) keeps the
// screen-reader text, which carries the date and time of each chip.
export async function extractCalendarRange() {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let i = 0; i < 40 && !document.querySelector('[role="main"]'); i++) await sleep(250);
  await sleep(1500);

  // Names in the side list ("내 캘린더", shared calendars): 이주호, 무신사, 이마트 …
  // A chip's screen-reader text names its calendar; match it against these.
  const calendars = new Set(
    [...document.querySelectorAll('input[type="checkbox"][aria-label]')]
      .map((el) => el.getAttribute("aria-label").trim())
      .filter(Boolean)
  );

  // Only the days the tab shows. Google keeps the chips of weeks viewed before in the page:
  // on 2026-10-30 a tab on /r/week/2026/10/4 also held this week's (10/26–30) chips.
  // The shown days come from the address (/r/week/2026/10/18: the week from that Sunday or Monday;
  // /r/day/…: that day; /r/month/…: that month); a chip is kept when a date in its text falls there.
  const at = location.pathname.match(/\/r\/(?:([a-z]+)\/)?(\d{4})\/(\d{1,2})\/(\d{1,2})/);
  const view = at?.[1] || (location.pathname.match(/\/r\/([a-z]+)/) || [])[1] || "week";
  const pick = at ? new Date(+at[2], +at[3] - 1, +at[4]) : new Date();
  pick.setHours(0, 0, 0, 0);
  let from = new Date(pick);
  let to;
  if (view === "day") {
    to = new Date(pick); to.setDate(pick.getDate() + 1);
  } else if (view === "month") {
    from = new Date(pick.getFullYear(), pick.getMonth(), 1);
    to = new Date(pick.getFullYear(), pick.getMonth() + 1, 1);
  } else {
    if (pick.getDay() > 1) from.setDate(pick.getDate() - pick.getDay());
    to = new Date(from); to.setDate(from.getDate() + 7);
  }
  const inShown = (label) => {
    const days = [...label.matchAll(/(\d{4})년 (\d{1,2})월 (\d{1,2})일/g)].map((m) => new Date(+m[1], +m[2] - 1, +m[3]));
    if (!days.length) return true; // no date in the text: kept as before
    return days.some((d) => d >= from && d < to) || (days[0] < from && days[days.length - 1] >= to);
  };
  const seen = new Set();
  return [...document.querySelectorAll("[data-eventid]")]
    .map((el) => {
      const id = el.getAttribute("data-eventid");
      const label = (el.textContent || "").replace(/\s+/g, " ").trim();
      // The 「근무 위치」 row (직장 / 변경 chips, id "_WL_…") carries data-eventid too but is no event
      // (2026-11-03, 맥미니 다음 주 읽기에서 「직장」 카드가 생김).
      if (!label || id.startsWith("_WL_") || seen.has(id) || !inShown(label)) return null;
      seen.add(id);
      // An all-day chip starts with the visible title run into "종일" ("[연차] 장서이종일, …").
      const parts = label.split(/,\s*/).map((p) => p.replace(/종일$/, "").trim()).filter(Boolean);
      const calendar = parts.find((p) => calendars.has(p)) || "";
      // Times and dates start the part ("오후 3시~오후 6시", "2026년 11월 4일…"): a title may hold "pm" or
      // "3시간" ("[EM5] 이마트 CSPM 내부 교육", "[3시간 시차] 윤민경"), which once made the title "캘린더: 교육".
      const meta = (p) => p === calendar || /^캘린더: /.test(p) || /^위치/.test(p) || /^종일$/.test(p) || /^\d{4}년 \d{1,2}월/.test(p) ||
        /^(오전|오후)\s*\d|^\d{1,2}(:\d{2})?\s*(am|pm)\b|^\d{1,2}:\d{2}/i.test(p);
      return {
        source: "calendar",
        title: parts.find((p) => !meta(p)) || parts[0],
        body: calendar ? `캘린더: ${calendar}\n${label}` : label,
        calendar,
        url: `https://calendar.google.com/calendar/event?eid=${encodeURIComponent(id)}`,
      };
    })
    .filter(Boolean);
}

// Gmail's Atom feed (/mail/u/N/feed/atom) names the account in its feed
// title, e.g. "Gmail - Inbox for name@company.com". Not a public contract
// either: if Google changes it, fix it here.
export function accountFromGmailFeed(xml) {
  const head = xml.split("<entry")[0];
  const m = head.match(/<title>[^<]*?([^\s<>()]+@[^\s<>()]+)[^<]*<\/title>/);
  return m ? m[1].toLowerCase() : null;
}
