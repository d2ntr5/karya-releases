const status = document.getElementById("status");
const capture = document.getElementById("capture");
const accountSelect = document.getElementById("account");
const accountState = document.getElementById("accountState");
const controls = document.getElementById("controls");
const login = document.getElementById("login");

function say(text, error = false) {
  status.className = error ? "error" : "";
  status.textContent = text;
}

async function run(message, doneText) {
  say("보내는 중…");
  const reply = await chrome.runtime.sendMessage(message);
  if (reply?.ok) say(doneText(reply.count) + (reply.note || ""));
  else say(reply?.error || "실패했습니다.", true);
  if (reply && !reply.ok && /로그인|계정/.test(reply.error || "")) refreshAccount();
  return reply?.ok;
}

// Fills the account list and turns every control on or off with the login state.
function showAccount(state) {
  accountSelect.replaceChildren();
  const add = (value, text) => accountSelect.add(new Option(text, value, false, value === (state.account || "")));
  if (!state.account) add("", "계정을 고르세요");
  for (const a of state.accounts) add(a.email, a.email);
  if (state.account && !state.loggedIn) add(state.account, state.account);

  const ready = Boolean(state.account && state.loggedIn);
  controls.disabled = !ready;
  login.hidden = !state.account || state.loggedIn;
  login.textContent = `${state.account}로 로그인`;
  login.dataset.email = state.account || "";

  if (!state.account) {
    accountState.className = "state";
    accountState.textContent = state.accounts.length
      ? "Chrome에 로그인된 Google 계정이 목록에 나옵니다."
      : "로그인된 Google 계정이 없습니다. Gmail에 먼저 로그인하세요.";
    say("계정을 고르면 사용할 수 있습니다.");
  } else if (state.loggedIn) {
    accountState.className = "state on";
    accountState.textContent = "로그인됨";
    if (status.textContent === "계정을 고르면 사용할 수 있습니다." || status.className === "error") say("");
  } else {
    accountState.className = "state off";
    accountState.textContent = "로그인 안 됨";
    say("이 계정이 Chrome에서 로그아웃돼 있습니다. 로그인한 뒤 팝업을 다시 여세요.", true);
  }
  if (ready) peek();
}

async function refreshAccount() {
  const reply = await chrome.runtime.sendMessage({ type: "accountState" });
  if (reply?.ok) showAccount(reply);
  else say(reply?.error || "계정을 확인하지 못했습니다.", true);
}

// Ticked rows in a Gmail list turn the main button into a batch send.
async function peek() {
  const reply = await chrome.runtime.sendMessage({ type: "peek" });
  capture.textContent = reply?.selected ? `선택한 메일 ${reply.selected}통 보내기` : "현재 탭 내용을 Karya로";
}

accountSelect.addEventListener("change", async () => {
  const reply = await chrome.runtime.sendMessage({ type: "setAccount", email: accountSelect.value });
  if (reply?.ok) showAccount(reply);
});

login.addEventListener("click", () =>
  chrome.tabs.create({ url: `https://accounts.google.com/AccountChooser?Email=${encodeURIComponent(login.dataset.email)}` })
);

capture.addEventListener("click", () =>
  run({ type: "captureActiveTab" }, (n) => `${n}개 항목을 보냈습니다.`)
);

document.querySelectorAll("[data-range]").forEach((button) =>
  button.addEventListener("click", () =>
    run({ type: "captureCalendar", range: button.dataset.range }, (n) => `일정 ${n}개를 보냈습니다.`)
  )
);

// 보낸 메일: the Gmail tab searches and reads each thread (can take a while for a month).
document.querySelectorAll("[data-sent]").forEach((button) =>
  button.addEventListener("click", () => {
    say("보낸 메일을 찾는 중… (Gmail 탭이 잠시 검색 화면으로 바뀝니다)");
    run({ type: "captureSentMail", range: button.dataset.sent }, (n) => `보낸 메일 스레드 ${n}개를 보냈습니다. 앱이 카드로 나눕니다.`);
  })
);

// 일정 관련 메일: reads the week's events, then searches Gmail for each.
document.querySelectorAll("[data-related]").forEach((button) =>
  button.addEventListener("click", () => {
    say("일정마다 관련 메일을 찾는 중… (일정이 많으면 1분 넘게)");
    run({ type: "captureRelatedMail", range: button.dataset.related }, (n) => `일정 ${n}개의 관련 메일을 보냈습니다.`);
  })
);

// 월별: this month by default; the background reads it week by week (up to half a minute).
const month = document.getElementById("month");
const now = new Date();
month.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
document.getElementById("captureMonth").addEventListener("click", () => {
  const [y, m] = (month.value || "").split("-").map(Number);
  if (!y || !m) return say("가져올 달을 고르세요.", true);
  say(`${y}년 ${m}월 일정을 주마다 읽는 중… (최대 30초)`);
  run({ type: "captureCalendarMonth", year: y, month: m }, (n) => `${y}년 ${m}월 일정 ${n}개를 보냈습니다.`);
});

document.getElementById("sendMemo").addEventListener("click", async () => {
  const memo = document.getElementById("memo");
  if (!memo.value.trim()) return;
  if (await run({ type: "sendMemo", text: memo.value.trim() }, () => "메모를 보냈습니다.")) memo.value = "";
});

refreshAccount();
